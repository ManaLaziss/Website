<?php

// Den direkten Aufruf verbieten
defined('_JEXEC') or die;

// Die Klasse erweitert die Klasse JControllerLegacy
class OnePageController extends JControllerLegacy
{
	
}