<?php

// Den direkten Aufruf verbieten
defined('_JEXEC') or die;

JToolbarHelper::title('OnePage');

echo 'Administration of OnePage Component';